from aiogram.fsm.state import StatesGroup, State

class LangState(StatesGroup):
    lang = State()
