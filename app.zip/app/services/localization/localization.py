import json
import os

from loguru import logger
from aiogram.fsm.context import FSMContext

class Localization:
    def __init__(self, localization_data: dict):
        # Загрузка локализации в формате, где можно обращаться через loc.default.txt
        self.default = self._set_language_data(localization_data.get('default', {}))

    def _set_language_data(self, data: dict):
        # Создаём структуру, чтобы можно было обращаться через атрибуты
        return type('LocalizationDefault', (object,), data)

async def load_localization(language: str) -> Localization:
    localization_file_path = 'app/services/localization/lang/'
    localization_file_name = language + '.json'

    try:
        # Загружаем данные из файла локализации
        with open(os.path.join(localization_file_path, localization_file_name), mode='r', encoding='utf8') as localization_file:
            localization_dict = json.load(localization_file)
            return Localization(localization_dict)
    except Exception as error:
        logger.error(f"Error loading localization file: {error}")
        return Localization({})  # Возвращаем пустой объект, если файл не найден

