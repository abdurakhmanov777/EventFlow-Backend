# from app.services.localization.localization import set_locale
# from config import LOCALIZATION_LANGUAGE

# set_locale(language=LOCALIZATION_LANGUAGE)
