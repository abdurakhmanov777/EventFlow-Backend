from typing import Any, Awaitable, Callable
from aiogram import BaseMiddleware, types

from app.services.localization.localization import load_localization

class Middleware(BaseMiddleware):
    def __init__(self) -> None:
        self.counter = 0

    async def __call__(
        self,
        handler: Callable[[types.Message, dict], Awaitable[Any]],
        event: types.Message,
        data: dict
    ) -> Any:
        self.counter += 1
        data['counter'] = self.counter

        # Получаем состояние пользователя
        state = data.get('state')
        user_data = await state.get_data() if state else {}

        # Получаем язык из состояния (по умолчанию 'ru')
        lang = user_data.get('lang', 'ru')

        # Загружаем данные для выбранного языка
        lang_data = await load_localization(lang)

        # Обновляем данные состояния с локализацией
        if state:
            await state.update_data(loc=lang_data)

        # Вызов основного обработчика
        result = await handler(event, data)

        # Попытка удалить сообщение после обработки
        try:
            await event.delete()
        except Exception:
            pass

        return result


# class MiddlewareMessage_and_CheckState(BaseMiddleware):
#     def __init__(self) -> None:
#         self.counter = 0

#     async def __call__(
#         self,
#         handler: Callable[[Message, dict], Awaitable[Any]],
#         event: Message,
#         data: dict
#     ) -> Any:
#         self.counter += 1
#         data['counter'] = self.counter
#         state = await rq.user_check(event.from_user.id, 'state')
#         data['state'] = state
#         if (str(event.content_type) == 'ContentType.CONTACT' or
#             str(state) in loc.template.state and len(event.text) < 50):
#             result = await handler(event, data)
#             try:
#                 '''Updating the «state» in the database'''
#                 num_id = await rq.user_check(event.from_user.id, 'num_id')
#                 if num_id != 0:
#                     await func.delete_message(event.from_user.id, num_id)
#                     await rq.user_update(event.from_user.id, 'num_id', 0)
#                 if result is not None:
#                     await rq.user_update(event.from_user.id, 'state', result)
#             except:
#                 pass
#         try:
#             '''Deleting a message'''
#             await event.delete()
#         except:
#             pass


# class MiddlewareCallback(BaseMiddleware):
#     def __init__(self) -> None:
#         self.counter = 0

#     async def __call__(
#         self,
#         handler: Callable[[CallbackQuery, bool], Awaitable[Any]],
#         event: CallbackQuery,
#         state: bool
#     ) -> Any:
#         self.counter += 1
#         result = await handler(event, state)
#         try:
#             '''Updating the «state» in the database'''
#             if result is not None:
#                 num_id = await rq.user_check(event.from_user.id, 'num_id')
#                 if num_id != 0:
#                     await func.delete_message(event.from_user.id, num_id)
#                     await rq.user_update(event.from_user.id, 'num_id', 0)
#                 await rq.user_update(event.from_user.id, 'state', result)
#         except:
#             pass
#         return result
