from typing import List
from aiogram import Bot, Dispatcher
from loguru import logger
from app.router.commands import router as commands
from app.middlewares.middlewares import Middleware

from aiogram.fsm.storage.memory import SimpleEventIsolation
from app.modules.multibot.polling_manager import PollingManager

# async def on_bot_startup(bot: Bot):
#     # await set_commands(bot)
#     print("Bot started!")
#     # await bot.send_message(chat_id=ADMIN_ID, text="Bot started!")


# async def on_bot_shutdown(bot: Bot):
#     print("Bot shutdown!")
#     # await bot.send_message(chat_id=ADMIN_ID, text="Bot shutdown!")

async def on_startup(bots: List[Bot]):
    logger.debug(f'Ботов включено: {len(bots)}')


# выключение ботов
async def on_shutdown(bots: List[Bot]):
    logger.debug(f'Ботов отключено: {len(bots)}')
    # for bot in bots:
    #     await on_bot_shutdown(bot)


def init_router() -> Dispatcher:
    dp = Dispatcher(events_isolation=SimpleEventIsolation())

    commands.message.middleware(Middleware())
    dp.include_router(commands)
    # commands.message.middleware(LocalizationMiddleware())
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    polling_manager = PollingManager()

    return dp, polling_manager
